import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Book } from '../book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-view-all-book',
  templateUrl: './view-all-book.component.html',
  styleUrls: ['./view-all-book.component.css']
})
export class ViewAllBookComponent implements OnInit {

  book!: Observable<Book[]>;

  constructor(private bookService: BookService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.book = this.bookService.getBookList();
  }


  deleteBook(bookId: number) {
    this.bookService.deleteBook(bookId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }


  updateBook(bookId: number) {
    this.router.navigate(['updatebook', bookId]);
  }


  getBook(bookId: number){
    this.router.navigate(['viewbook', bookId]);
  }

}
