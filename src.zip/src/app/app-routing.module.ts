import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddAddressComponent } from './add-address/add-address.component';
import { AddBookComponent } from './add-book/add-book.component';
import { AddBookorderComponent } from './add-bookorder/add-bookorder.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { AddOrderdetailsComponent } from './add-orderdetails/add-orderdetails.component';
import { AddReviewComponent } from './add-review/add-review.component';
// import { AddReviewComponent } from './add-review/add-review.component';
import { AddUserComponent } from './add-user/add-user.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthGaurdService } from './service/auth-gaurd.service';
import { UpdateAddressComponent } from './update-address/update-address.component';
import { UpdateBookComponent } from './update-book/update-book.component';
import { UpdateBookorderComponent } from './update-bookorder/update-bookorder.component';
import { UpdateCategoryComponent } from './update-category/update-category.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { UpdateOrderdetailsComponent } from './update-orderdetails/update-orderdetails.component';
import { UpdateReviewComponent } from './update-review/update-review.component';
// import { UpdateReviewComponent } from './update-review/update-review.component';
import { ViewAddressComponent } from './view-address/view-address.component';
import { ViewAllAddressComponent } from './view-all-address/view-all-address.component';
import { ViewAllBookComponent } from './view-all-book/view-all-book.component';
import { ViewAllBookorderComponent } from './view-all-bookorder/view-all-bookorder.component';
import { ViewAllCategoryComponent } from './view-all-category/view-all-category.component';
import { ViewAllCustomerComponent } from './view-all-customer/view-all-customer.component';
import { ViewAllOrderdetailsComponent } from './view-all-orderdetails/view-all-orderdetails.component';
import { ViewAllReviewComponent } from './view-all-review/view-all-review.component';
// import { ViewAllReviewComponent } from './view-all-review/view-all-review.component';
import { ViewBookComponent } from './view-book/view-book.component';
import { ViewBookorderComponent } from './view-bookorder/view-bookorder.component';
import { ViewCategoryComponent } from './view-category/view-category.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';
import { ViewOrderdetailsComponent } from './view-orderdetails/view-orderdetails.component';
import { ViewReviewComponent } from './view-review/view-review.component';
// import { ViewReviewComponent } from './view-review/view-review.component';

const routes: Routes = [
  { path: '', redirectTo: 'category', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
{ path: 'logout', component: LogoutComponent, canActivate: [AuthGaurdService] },
  { path: 'category', component: ViewAllCategoryComponent },
  { path: 'newcategory', component: AddCategoryComponent },
  { path: 'updatecategory/:categoryId', component: UpdateCategoryComponent },
  { path: 'viewcategory/:categoryId', component: ViewCategoryComponent },

  { path: 'address', component: ViewAllAddressComponent },
  { path: 'newaddress', component: AddAddressComponent },
  { path: 'updateaddress/:addressId', component: UpdateAddressComponent },
  { path: 'viewaddress/:addressId', component: ViewAddressComponent },

  { path: 'customer', component: ViewAllCustomerComponent},
  { path: 'newcustomer', component: AddCustomerComponent },
  { path: 'updatecustomer/:customerId', component: UpdateCustomerComponent },
  { path: 'viewcustomer/:customerId', component: ViewCustomerComponent },

  { path: 'book', component: ViewAllBookComponent},
  { path: 'newbook', component: AddBookComponent },
  { path: 'updatebook/:bookId', component: UpdateBookComponent },
  { path: 'viewbook/:bookId', component: ViewBookComponent },

  { path: 'orderdetails', component: ViewAllOrderdetailsComponent},
  { path: 'neworderdetails', component: AddOrderdetailsComponent },
  { path: 'updateorderdetails/:orderDetailsId', component: UpdateOrderdetailsComponent },
  { path: 'vieworderdetails/:orderDetailsId', component: ViewOrderdetailsComponent },

  { path: 'bookorder', component: ViewAllBookorderComponent},
  { path: 'newbookorder', component: AddBookorderComponent },
  { path: 'updatebookorder/:orderId', component: UpdateBookorderComponent },
  { path: 'viewbookorder/:orderId', component: ViewBookorderComponent },

  { path: 'review', component: ViewAllReviewComponent},
  { path: 'newreview', component: AddReviewComponent },
  { path: 'updatereview/:reviewId', component: UpdateReviewComponent },
  { path: 'viewreview/:reviewId', component: ViewReviewComponent },

  { path: 'newuser', component: AddUserComponent },
  { path: 'newuser/login', component: LoginComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
