import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateBookorderComponent } from './update-bookorder.component';

describe('UpdateBookorderComponent', () => {
  let component: UpdateBookorderComponent;
  let fixture: ComponentFixture<UpdateBookorderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateBookorderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateBookorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
