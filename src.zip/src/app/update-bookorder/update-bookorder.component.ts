import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookOrderService } from '../book-order.service';
import { BookOrder } from '../order';

@Component({
  selector: 'app-update-bookorder',
  templateUrl: './update-bookorder.component.html',
  styleUrls: ['./update-bookorder.component.css']
})
export class UpdateBookorderComponent implements OnInit {

  orderId!: number;
  bookOrder: BookOrder = new BookOrder;
  submitted = false;

  constructor(private route: ActivatedRoute,private router: Router,
    private bookOrderService: BookOrderService) { }

  ngOnInit() {

    this.bookOrder = new BookOrder();

    this.orderId = this.route.snapshot.params['orderId'];
   
    this.bookOrderService.getBookOrder(this.orderId)
      .subscribe(data => {
        console.log(data)
        this.bookOrder = data;
      }, error => console.log(error));
  }

 
  updateBookOrder() {
    this.bookOrderService.updateBookOrder( this.bookOrder)
      .subscribe(data => {
        console.log(data);
        this.bookOrder = new BookOrder();
        this.gotoList();
      }, error => console.log(error));
  }
 

  onSubmit() {
    this.submitted = true;
    this.updateBookOrder();    
  }

 
  gotoList() {
    this.router.navigate(['/bookorder']);
  }

}
