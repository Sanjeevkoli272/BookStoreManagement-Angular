export class Address {
    addressId: number = 0;
    address: string = "";
    city: string = "";
    country: string = "";
    pincode: string = "";
}