import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Address } from '../address';
import { AddressService } from '../address.service';

@Component({
  selector: 'app-view-all-address',
  templateUrl: './view-all-address.component.html',
  styleUrls: ['./view-all-address.component.css']
})
export class ViewAllAddressComponent implements OnInit {

  address!: Observable<Address[]>;

  constructor(private addressService: AddressService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.address = this.addressService.getAddressList();
  }


  removeAddress(addressId: number) {
    this.addressService.deleteAddress(addressId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }


  updateAddress(addressId: number) {
    this.router.navigate(['updateaddress', addressId]);
  }


  getAddress(addressId: number){
    this.router.navigate(['viewaddress', addressId]);
  }
 

}
