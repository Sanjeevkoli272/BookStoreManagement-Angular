import { Book } from "./book";

export class OrderDetails {
    orderDetailsId: number = 0;
    quantity: number = 0;
    subtotal: number = 0;
    book: Book = new Book;
}