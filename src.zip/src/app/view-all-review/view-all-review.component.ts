import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Review } from '../review';
import { ReviewService } from '../review.service';

@Component({
  selector: 'app-view-all-review',
  templateUrl: './view-all-review.component.html',
  styleUrls: ['./view-all-review.component.css']
})
export class ViewAllReviewComponent implements OnInit {

  review!: Observable<Review[]>;
  constructor(private reviewService: ReviewService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.review = this.reviewService.getReviewList();
  }
  
  updateReview(reviewId: number) {
    this.router.navigate(['updatereview', reviewId]);
  }


  getReview(reviewId: number){
    this.router.navigate(['viewreview', reviewId]);
  }
}
