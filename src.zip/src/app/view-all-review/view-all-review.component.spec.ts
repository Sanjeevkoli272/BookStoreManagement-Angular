import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllReviewComponent } from './view-all-review.component';

describe('ViewAllReviewComponent', () => {
  let component: ViewAllReviewComponent;
  let fixture: ComponentFixture<ViewAllReviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllReviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
