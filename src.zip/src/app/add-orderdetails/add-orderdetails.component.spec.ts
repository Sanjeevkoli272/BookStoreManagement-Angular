import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOrderdetailsComponent } from './add-orderdetails.component';

describe('AddOrderdetailsComponent', () => {
  let component: AddOrderdetailsComponent;
  let fixture: ComponentFixture<AddOrderdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddOrderdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOrderdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
