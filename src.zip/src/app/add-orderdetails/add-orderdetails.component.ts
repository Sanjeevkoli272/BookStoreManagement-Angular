import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Book } from '../book';
import { BookService } from '../book.service';
import { OrderDetailsService } from '../order-details.service';
import { OrderDetails } from '../orderDetails';

@Component({
  selector: 'app-add-orderdetails',
  templateUrl: './add-orderdetails.component.html',
  styleUrls: ['./add-orderdetails.component.css']
})
export class AddOrderdetailsComponent implements OnInit {

  books!: Observable<Book[]>;
  orderdetails: OrderDetails = new OrderDetails();
  submitted = false;

  constructor(private orderdetailsService: OrderDetailsService, private bookService: BookService, private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.books = this.bookService.getBookList();
  
    }
  newOrderDetails(): void {
    this.submitted = false;
    this.orderdetails = new OrderDetails();
  }

  
  save()  { 
    this.orderdetailsService.addOrderDetails(this.orderdetails).subscribe(data => {
      console.log(data)
      this.orderdetails = new OrderDetails();
      this.gotoList();
    }, 
    error => console.log(error));
  }


  onSubmit() {
    this.submitted = true;
    this.save();    
  }


  gotoList() {
    this.router.navigate(['/orderdetails']);
  }

}
