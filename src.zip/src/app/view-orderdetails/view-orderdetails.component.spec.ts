import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewOrderdetailsComponent } from './view-orderdetails.component';

describe('ViewOrderdetailsComponent', () => {
  let component: ViewOrderdetailsComponent;
  let fixture: ComponentFixture<ViewOrderdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewOrderdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewOrderdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
