import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Book } from '../book';
import { OrderDetailsService } from '../order-details.service';
import { OrderDetails } from '../orderDetails';

@Component({
  selector: 'app-view-orderdetails',
  templateUrl: './view-orderdetails.component.html',
  styleUrls: ['./view-orderdetails.component.css']
})
export class ViewOrderdetailsComponent implements OnInit {

  orderDetailsId: number = 0;
  orderDetails: OrderDetails = new OrderDetails;
  book:Book=new Book;

  constructor(private route: ActivatedRoute, private router: Router, private orderDetailsService: OrderDetailsService) { }

  ngOnInit() {
    this.orderDetails = new OrderDetails();

    this.orderDetailsId = this.route.snapshot.params['orderDetailsId'];
   

    this.orderDetailsService.getOrderDetails(this.orderDetailsId)
      .subscribe(data => {
        console.log(data)
        this.orderDetails = data;
      }, error => console.log(error));
  }

  list(){
    this.router.navigate(['orderdetails']);
  }

}
