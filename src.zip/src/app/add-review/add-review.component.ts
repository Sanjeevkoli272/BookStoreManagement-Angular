import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Book } from '../book';
import { BookService } from '../book.service';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Review } from '../review';
import { ReviewService } from '../review.service';

@Component({
  selector: 'app-add-review',
  templateUrl: './add-review.component.html',
  styleUrls: ['./add-review.component.css']
})
export class AddReviewComponent implements OnInit {

  books!: Observable<Book[]>;
  customers!: Observable<Customer[]>;
 review:Review = new Review();
  submitted = false;

  constructor(private reviewService:ReviewService, private bookService: BookService, private customerService:CustomerService, private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.books = this.bookService.getBookList();
    this.customers = this.customerService.getCustomerList();
  
    }
  newReview(): void {
    this.submitted = false;
    this.review = new Review();
  }

  
  save()  { 
    this.reviewService.addReview(this.review).subscribe(data => {
      console.log(data)
      this.review = new Review();
      this.gotoList();
    }, 
     error => console.log(error));
  }


  onSubmit() {
    this.submitted = true;
    this.save();    
  }


  gotoList() {
    this.router.navigate(['/review']);
  }


}
