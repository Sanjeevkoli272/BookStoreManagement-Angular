import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-view-all-customer',
  templateUrl: './view-all-customer.component.html',
  styleUrls: ['./view-all-customer.component.css']
})
export class ViewAllCustomerComponent implements OnInit {

  customer!: Observable<Customer[]>;

  constructor(private customerService: CustomerService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.customer = this.customerService.getCustomerList();
  }


  deleteCustomer(customerId: number) {
    this.customerService.deleteCustomer(customerId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }


  updateCustomer(customerId: number) {
    this.router.navigate(['updatecustomer', customerId]);
  }


  getCustomer(customerId: number){
    this.router.navigate(['viewcustomer', customerId]);
  }
 


}
