import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllBookorderComponent } from './view-all-bookorder.component';

describe('ViewAllBookorderComponent', () => {
  let component: ViewAllBookorderComponent;
  let fixture: ComponentFixture<ViewAllBookorderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllBookorderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllBookorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
