import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { BookOrderService } from '../book-order.service';
import { BookOrder } from '../order';

@Component({
  selector: 'app-view-all-bookorder',
  templateUrl: './view-all-bookorder.component.html',
  styleUrls: ['./view-all-bookorder.component.css']
})
export class ViewAllBookorderComponent implements OnInit {

  bookOrder!: Observable<BookOrder[]>;

  constructor(private bookOrderService: BookOrderService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.bookOrder = this.bookOrderService.getBookOrderList();
  }


  deleteBookOrder(orderId: number) {
    this.bookOrderService.deleteBookOrder(orderId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }


  updateBookOrder(orderId: number) {
    this.router.navigate(['updatebookorder', orderId]);
  }


  getBookOrder(orderId: number){
    this.router.navigate(['viewbookorder', orderId]);
  }


}
