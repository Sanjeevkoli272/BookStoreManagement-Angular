import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteOrderdetailsComponent } from './delete-orderdetails.component';

describe('DeleteOrderdetailsComponent', () => {
  let component: DeleteOrderdetailsComponent;
  let fixture: ComponentFixture<DeleteOrderdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteOrderdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteOrderdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
