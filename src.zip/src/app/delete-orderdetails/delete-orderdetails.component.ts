import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-orderdetails',
  templateUrl: './delete-orderdetails.component.html',
  styleUrls: ['./delete-orderdetails.component.css']
})
export class DeleteOrderdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
