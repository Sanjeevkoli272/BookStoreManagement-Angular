import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Address } from '../address';
import { AddressService } from '../address.service';

@Component({
  selector: 'app-view-address',
  templateUrl: './view-address.component.html',
  styleUrls: ['./view-address.component.css']
})
export class ViewAddressComponent implements OnInit {

  addressId: number = 0;
  address: Address = new Address;

  constructor(private route: ActivatedRoute, private router: Router, private addressService: AddressService) { }

  ngOnInit() {
    this.address = new Address();

    this.addressId = this.route.snapshot.params['addressId'];

    this.addressService.getAddress(this.addressId)
      .subscribe(data => {
        console.log(data)
        this.address = data;
      }, error => console.log(error));
  }

  list(){
    this.router.navigate(['address']);
  }
}
