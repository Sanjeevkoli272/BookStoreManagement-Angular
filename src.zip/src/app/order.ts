import { Customer } from "./customer";
import { OrderDetails } from "./orderDetails";

export class BookOrder {
    orderId: number = 0;
    orderDate: string = "";
    orderTotal: string = "";
    status: string = "";
    paymentMethod: string = "";
    recipientName: string = "";
    recipientPhone: string = "";
    orderDetails: OrderDetails= new OrderDetails;
    customer: Customer = new Customer;
}