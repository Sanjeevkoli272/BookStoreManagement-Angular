import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Address } from '../address';
import { AddressService } from '../address.service';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  addresses!: Observable<Address[]>;
  customer: Customer = new Customer();
  submitted = false;

  constructor(private customerService: CustomerService, private addressService: AddressService, private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.addresses = this.addressService.getAddressList();
  
    }
  newCustomer(): void {
    this.submitted = false;
    this.customer = new Customer();
  }

  
  save()  { 
    this.customerService.addCustomer(this.customer).subscribe(data => {
      console.log(data)
      this.customer = new Customer();
      this.gotoList();
    }, 
    error => console.log(error));
  }


  onSubmit() {
    this.submitted = true;
    this.save();    
  }


  gotoList() {
    this.router.navigate(['/customer']);
  }

}
