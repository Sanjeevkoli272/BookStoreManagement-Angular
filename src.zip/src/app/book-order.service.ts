import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookOrderService {

  private baseUrl = 'http://localhost:8092/api/bookorder';

  constructor(private http: HttpClient) { }

  getBookOrder(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/id/${id}`);
  }

  addBookOrder(BookOrder: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/newbookorder`, BookOrder);
  }

  updateBookOrder( value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/update`, value);
  }

  deleteBookOrder(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/delete/${id}`, { responseType: 'text' });
  }

  getBookOrderList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/viewall`);
  }
}
