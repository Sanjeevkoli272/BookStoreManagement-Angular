export class User {
    userId: number = 0;
    email: string = "";
    password: string = "";
    
}
