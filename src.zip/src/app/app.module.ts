import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { DeleteCategoryComponent } from './delete-category/delete-category.component';
import { UpdateCategoryComponent } from './update-category/update-category.component';
import { ViewCategoryComponent } from './view-category/view-category.component';
import { ViewAllCategoryComponent } from './view-all-category/view-all-category.component';
import { AddAddressComponent } from './add-address/add-address.component';
import { DeleteAddressComponent } from './delete-address/delete-address.component';
import { UpdateAddressComponent } from './update-address/update-address.component';
import { ViewAddressComponent } from './view-address/view-address.component';
import { ViewAllAddressComponent } from './view-all-address/view-all-address.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { DeleteCustomerComponent } from './delete-customer/delete-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';
import { ViewAllCustomerComponent } from './view-all-customer/view-all-customer.component';
import { AddBookComponent } from './add-book/add-book.component';
import { DeleteBookComponent } from './delete-book/delete-book.component';
import { UpdateBookComponent } from './update-book/update-book.component';
import { ViewBookComponent } from './view-book/view-book.component';
import { ViewAllBookComponent } from './view-all-book/view-all-book.component';
import { AddOrderdetailsComponent } from './add-orderdetails/add-orderdetails.component';
import { DeleteOrderdetailsComponent } from './delete-orderdetails/delete-orderdetails.component';
import { UpdateOrderdetailsComponent } from './update-orderdetails/update-orderdetails.component';
import { ViewOrderdetailsComponent } from './view-orderdetails/view-orderdetails.component';
import { ViewAllOrderdetailsComponent } from './view-all-orderdetails/view-all-orderdetails.component';
import { CommonModule } from '@angular/common';
import { AddBookorderComponent } from './add-bookorder/add-bookorder.component';
import { DeleteBookorderComponent } from './delete-bookorder/delete-bookorder.component';
import { UpdateBookorderComponent } from './update-bookorder/update-bookorder.component';
import { ViewBookorderComponent } from './view-bookorder/view-bookorder.component';
import { ViewAllBookorderComponent } from './view-all-bookorder/view-all-bookorder.component';
// import { AddReviewComponent } from './add-review/add-review.component';
// import { DeleteReviewComponent } from './delete-review/delete-review.component';
// import { UpdateReviewComponent } from './update-review/update-review.component';
// import { ViewReviewComponent } from './view-review/view-review.component';
// import { ViewAllReviewComponent } from './view-all-review/view-all-review.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AddUserComponent } from './add-user/add-user.component';
import { AddReviewComponent } from './add-review/add-review.component';
import { UpdateReviewComponent } from './update-review/update-review.component';
import { ViewReviewComponent } from './view-review/view-review.component';
import { ViewAllReviewComponent } from './view-all-review/view-all-review.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    LogoutComponent,
    AddUserComponent,
    AddCategoryComponent,
    DeleteCategoryComponent,
    UpdateCategoryComponent,
    ViewCategoryComponent,
    ViewAllCategoryComponent,
    AddAddressComponent,
    DeleteAddressComponent,
    UpdateAddressComponent,
    ViewAddressComponent,
    ViewAllAddressComponent,
    AddCustomerComponent,
    DeleteCustomerComponent,
    UpdateCustomerComponent,
    ViewCustomerComponent,
    ViewAllCustomerComponent,
    AddBookComponent,
    DeleteBookComponent,
    UpdateBookComponent,
    ViewBookComponent,
    ViewAllBookComponent,
    AddOrderdetailsComponent,
    DeleteOrderdetailsComponent,
    UpdateOrderdetailsComponent,
    ViewOrderdetailsComponent,
    ViewAllOrderdetailsComponent,
    AddBookorderComponent,
    DeleteBookorderComponent,
    UpdateBookorderComponent,
    ViewBookorderComponent,
    ViewAllBookorderComponent,
    AddReviewComponent,
    UpdateReviewComponent,
    ViewReviewComponent,
    ViewAllReviewComponent,
    // AddReviewComponent,
    // DeleteReviewComponent,
    // UpdateReviewComponent,
    // ViewReviewComponent,
    // ViewAllReviewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    CommonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
