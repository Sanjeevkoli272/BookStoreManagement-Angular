import { Book } from "./book";
import { Customer } from "./customer";

export class Review {
    reviewId: number = 0;
    headLine: string = "";
    comments: string = "";
    rating: number = 0;
    reviewOn: string = "";
    book: Book = new Book;
    customer: Customer = new Customer;
    
}