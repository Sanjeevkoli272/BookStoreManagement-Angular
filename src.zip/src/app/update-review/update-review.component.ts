import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Review } from '../review';
import { ReviewService } from '../review.service';

@Component({
  selector: 'app-update-review',
  templateUrl: './update-review.component.html',
  styleUrls: ['./update-review.component.css']
})
export class UpdateReviewComponent implements OnInit {

  reviewId!: number;
  review: Review = new Review;
  submitted = false;

  constructor(private route: ActivatedRoute,private router: Router,
    private reviewService:ReviewService) { }

  ngOnInit() {

    this.review = new Review();

    this.reviewId = this.route.snapshot.params['reviewId'];
   
    this.reviewService.getReview(this.reviewId)
      .subscribe(data => {
        console.log(data)
        this.review = data;
      }, error => console.log(error));
  }

 
  updateReview() {
    this.reviewService.updateReview(this.reviewId, this.review)
      .subscribe(data => {
        console.log(data);
        this.review = new Review();
        this.gotoList();
      }, error => console.log(error));
  }
 

  onSubmit() {
    this.submitted = true;
    this.updateReview();    
  }

 
  gotoList() {
    this.router.navigate(['review']);
  }
}
