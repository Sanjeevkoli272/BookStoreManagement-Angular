import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderDetailsService {

  private baseUrl = 'http://localhost:8092/api/orderdetails';

  constructor(private http: HttpClient) { }

  getOrderDetails(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/view/${id}`);
  }

  addOrderDetails(OrderDetails: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/neworderdetails`, OrderDetails);
  }

  updateOrderDetails(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/update/${id}`, value);
  }

  deleteOrderDetails(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/delete/${id}`, { responseType: 'text' });
  }

  getOrderDetailsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/viewall`);
  }
}
