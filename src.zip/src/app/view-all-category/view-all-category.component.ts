import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Category } from '../category';
import { CategoryService } from '../category.service';

@Component({
  selector: 'app-view-all-category',
  templateUrl: './view-all-category.component.html',
  styleUrls: ['./view-all-category.component.css']
})
export class ViewAllCategoryComponent implements OnInit {

  category!: Observable<Category[]>;

  constructor(private categoryService: CategoryService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.category = this.categoryService.getCategoryList();
  }


  removeCategory(categoryId: number) {
    this.categoryService.deleteCategory(categoryId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }


  updateCategory(categoryId: number) {
    this.router.navigate(['updatecategory', categoryId]);
  }


  getCategory(categoryId: number){
    this.router.navigate(['viewcategory', categoryId]);
  }
 


}
