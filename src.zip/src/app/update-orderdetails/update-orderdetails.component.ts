import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderDetailsService } from '../order-details.service';
import { OrderDetails } from '../orderDetails';

@Component({
  selector: 'app-update-orderdetails',
  templateUrl: './update-orderdetails.component.html',
  styleUrls: ['./update-orderdetails.component.css']
})
export class UpdateOrderdetailsComponent implements OnInit {

  orderDetailsId!: number;
  orderdetails: OrderDetails = new OrderDetails;
  submitted = false;

  constructor(private route: ActivatedRoute,private router: Router,
    private orderDetailsService: OrderDetailsService) { }

  ngOnInit() {

    this.orderdetails = new OrderDetails();

    this.orderDetailsId = this.route.snapshot.params['orderDetailsId'];
   
    this.orderDetailsService.getOrderDetails(this.orderDetailsId)
    .subscribe(data => {
      console.log(data)
      this.orderdetails = data;
    }, error => console.log(error));
}

 
  updateOrderDetails() {
    
    this.orderDetailsService.updateOrderDetails( this.orderDetailsId,this.orderdetails)
      .subscribe(data => {
        console.log(data);
        this.orderdetails = new OrderDetails();
        this.gotoList();
      }, error => console.log(error));
  }
 

  onSubmit() {
    this.submitted = true;
    this.updateOrderDetails();    
  }

 
  gotoList() {
    this.router.navigate(['/orderdetails']);
  }

}
