import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateOrderdetailsComponent } from './update-orderdetails.component';

describe('UpdateOrderdetailsComponent', () => {
  let component: UpdateOrderdetailsComponent;
  let fixture: ComponentFixture<UpdateOrderdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateOrderdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateOrderdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
