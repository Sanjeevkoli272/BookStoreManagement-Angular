import { Address } from "./address";

export class Customer {
    customerId: number = 0;
    fullName: string = "";
    mobileNumber: string = "";
    registerOn: string = "";
    address: Address= new Address;
}