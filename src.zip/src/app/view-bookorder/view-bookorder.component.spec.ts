import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBookorderComponent } from './view-bookorder.component';

describe('ViewBookorderComponent', () => {
  let component: ViewBookorderComponent;
  let fixture: ComponentFixture<ViewBookorderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewBookorderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBookorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
