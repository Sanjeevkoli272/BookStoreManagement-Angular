import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookOrderService } from '../book-order.service';
import { BookOrder } from '../order';

@Component({
  selector: 'app-view-bookorder',
  templateUrl: './view-bookorder.component.html',
  styleUrls: ['./view-bookorder.component.css']
})
export class ViewBookorderComponent implements OnInit {

  orderId: number = 0;
  bookOrder: BookOrder = new BookOrder;

  constructor(private route: ActivatedRoute, private router: Router, private bookOrderService: BookOrderService) { }

  ngOnInit() {
    this.bookOrder = new BookOrder();

    this.orderId = this.route.snapshot.params['orderId'];

    this.bookOrderService.getBookOrder(this.orderId)
      .subscribe(data => {
        console.log(data)
        this.bookOrder = data;
      }, error => console.log(error));
  }

  list(){
    this.router.navigate(['bookorder']);
  }

}
