import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Category } from '../category';
import { CategoryService } from '../category.service';

@Component({
  selector: 'app-update-category',
  templateUrl: './update-category.component.html',
  styleUrls: ['./update-category.component.css']
})
export class UpdateCategoryComponent implements OnInit {

  categoryId!: number;
  category: Category = new Category;
  submitted = false;

  constructor(private route: ActivatedRoute,private router: Router,
    private categoryService: CategoryService) { }

  ngOnInit() {

    this.category = new Category();

    this.categoryId = this.route.snapshot.params['categoryId'];
   
    this.categoryService.getCategory(this.categoryId)
      .subscribe(data => {
        console.log(data)
        this.category = data;
      }, error => console.log(error));
  }

 
  updateCategory() {
    this.categoryService.updateCategory(this.categoryId, this.category)
      .subscribe(data => {
        console.log(data);
        this.category = new Category();
        this.gotoList();
      }, error => console.log(error));
  }
 

  onSubmit() {
    this.submitted = true;
    this.updateCategory();    
  }

 
  gotoList() {
    this.router.navigate(['/category']);
  }
  

}
