import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { OrderDetailsService } from '../order-details.service';
import { OrderDetails } from '../orderDetails';

@Component({
  selector: 'app-view-all-orderdetails',
  templateUrl: './view-all-orderdetails.component.html',
  styleUrls: ['./view-all-orderdetails.component.css']
})
export class ViewAllOrderdetailsComponent implements OnInit {

  orderDetails!: Observable<OrderDetails[]>;

  constructor(private orderdetailsService: OrderDetailsService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.orderDetails = this.orderdetailsService.getOrderDetailsList();
  }


  removeOrderDetails(orderDetailsId: number) {
    this.orderdetailsService.deleteOrderDetails(orderDetailsId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }


  updateOrderDetails(orderDetailsId: number) {
    this.router.navigate(['updateorderdetails', orderDetailsId]);
  }


  getOrderDetails(orderDetailsId: number){
    this.router.navigate(['vieworderdetails', orderDetailsId]);
  }

}
