import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllOrderdetailsComponent } from './view-all-orderdetails.component';

describe('ViewAllOrderdetailsComponent', () => {
  let component: ViewAllOrderdetailsComponent;
  let fixture: ComponentFixture<ViewAllOrderdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllOrderdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllOrderdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
