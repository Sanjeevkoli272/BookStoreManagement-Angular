import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReviewService {

  private baseUrl = 'http://localhost:8092/api/review';

  constructor(private http: HttpClient) { }

  getReview(reviewId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/get/${reviewId}`);
  }

  addReview(review: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/newreview`, review);
  }

  updateReview(reviewId: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/update/${reviewId}`, value);
  }

  deleteReview(reviewId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/delete/${reviewId}`, { responseType: 'text' });
  }

  getReviewList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/all`);
  }

}
