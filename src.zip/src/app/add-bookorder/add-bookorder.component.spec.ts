import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddBookorderComponent } from './add-bookorder.component';

describe('AddBookorderComponent', () => {
  let component: AddBookorderComponent;
  let fixture: ComponentFixture<AddBookorderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddBookorderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBookorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
