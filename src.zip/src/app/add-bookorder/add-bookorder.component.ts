import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { BookOrderService } from '../book-order.service';
import { BookOrder } from '../order';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { OrderDetailsService } from '../order-details.service';
import { OrderDetails } from '../orderDetails';

@Component({
  selector: 'app-add-bookorder',
  templateUrl: './add-bookorder.component.html',
  styleUrls: ['./add-bookorder.component.css']
})
export class AddBookorderComponent implements OnInit {


  customers!: Observable<Customer[]>;
  orderDetails!: Observable<OrderDetails[]>;
  bookorder: BookOrder = new BookOrder();
  submitted = false;

  constructor(private bookorderService: BookOrderService, private customerService: CustomerService, private orderDetailsService: OrderDetailsService, private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.customers = this.customerService.getCustomerList();
    this.orderDetails = this.orderDetailsService.getOrderDetailsList();
  
    }
  newBookOrder(): void {
    this.submitted = false;
    this.bookorder = new BookOrder();
  }

  
  save()  { 
    this.bookorderService.addBookOrder(this.bookorder).subscribe(data => {
      console.log(data)
      this.bookorder = new BookOrder();
      this.gotoList();
    }, 
    error => console.log(error));
  }


  onSubmit() {
    this.submitted = true;
    this.save();    
  }


  gotoList() {
    this.router.navigate(['/bookorder']);
  }

}
