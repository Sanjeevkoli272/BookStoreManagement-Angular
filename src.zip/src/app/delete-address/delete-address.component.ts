import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-address',
  templateUrl: './delete-address.component.html',
  styleUrls: ['./delete-address.component.css']
})
export class DeleteAddressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
