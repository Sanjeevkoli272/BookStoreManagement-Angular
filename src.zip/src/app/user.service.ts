import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = 'http://localhost:8092/api/user';
  

  constructor(private http: HttpClient) { }

 

  addUser(user: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/add`, user);
  }

  

  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/delete/${id}`, { responseType: 'text' });
  }

  

}
