import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Review } from '../review';
import { ReviewService } from '../review.service';

@Component({
  selector: 'app-view-review',
  templateUrl: './view-review.component.html',
  styleUrls: ['./view-review.component.css']
})
export class ViewReviewComponent implements OnInit {

  reviewId: number = 0;
  review: Review = new Review;
  constructor(private route: ActivatedRoute, private router: Router, private reviewService: ReviewService) { }

ngOnInit(){
  this.review = new Review();

    this.reviewId = this.route.snapshot.params['reviewId'];

    this.reviewService.getReview(this.reviewId)
      .subscribe(data => {
        console.log(data)
        this.review = data;
      }, error => console.log(error));

}

list(){
  this.router.navigate(['review']);
}

}
