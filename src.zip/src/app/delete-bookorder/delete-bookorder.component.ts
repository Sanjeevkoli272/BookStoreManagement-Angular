import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-bookorder',
  templateUrl: './delete-bookorder.component.html',
  styleUrls: ['./delete-bookorder.component.css']
})
export class DeleteBookorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
