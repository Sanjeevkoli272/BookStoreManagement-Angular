import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteBookorderComponent } from './delete-bookorder.component';

describe('DeleteBookorderComponent', () => {
  let component: DeleteBookorderComponent;
  let fixture: ComponentFixture<DeleteBookorderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteBookorderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteBookorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
