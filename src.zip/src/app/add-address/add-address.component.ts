import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Address } from '../address';
import { AddressService } from '../address.service';

@Component({
  selector: 'app-add-address',
  templateUrl: './add-address.component.html',
  styleUrls: ['./add-address.component.css']
})
export class AddAddressComponent implements OnInit {

  address: Address = new Address();
  submitted = false;

  constructor(private addressService: AddressService,  private router: Router) { }

  ngOnInit() {
  }

  newAddress(): void {
    this.submitted = false;
    this.address = new Address();
  }

  save() {
    this.addressService.addAddress(this.address).subscribe(data => {
      console.log(data)
      this.address = new Address();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/address']);
  }

}
